// app/app.module.js
angular.module('libraryApp', ['ngRoute']);
