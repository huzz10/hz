var app = angular.module('movieApp', []);
