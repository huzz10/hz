angular.module('taskManagerApp', []);
